document.getElementById("salvar").addEventListener("click", async () => {
  const titulo = document.getElementById("titulo").value;
  const link = document.getElementById("link").value;
  const imagem = document.getElementById("imagem").value;
  
  const favorito = { titulo, link, imagem, criadoEm: Date.now() };
  
  // Recupera os favoritos existentes e adiciona o novo
  chrome.storage.local.get("mfc_favoritos", (result) => {
    const favoritos = Array.isArray(result.mfc_favoritos) ? result.mfc_favoritos : [];
    
    // Verifica se o link já existe
    const jaExiste = favoritos.some(item => item.link === link);
    if (jaExiste) {
      alert("Este favorito já foi salvo.");
      return;
    }
    
    favoritos.push(favorito);
    
    chrome.storage.local.set({ "mfc_favoritos": favoritos }, () => {
      alert("Favorito salvo!");
      
      // Envia todos os favoritos salvos para a página
      window.postMessage({
        type: "MFC_FAVORITOS_RECEBIDOS",
        favoritos
      }, "*");
    });
  });
});

// Preenche automaticamente o campo de título com o título da aba
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs[0];
  if (tab) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => document.title
    }, (results) => {
      if (results && results[0]) {
        document.getElementById("titulo").value = results[0].result;
      }
    });
  }
});

// Preenche automaticamente o campo de imagem com a meta og:image ou primeira imagem da página
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs[0];
  if (tab) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const ogImage = document.querySelector('meta[property="og:image"]');
        if (ogImage && ogImage.content) {
          return ogImage.content;
        }
        
        const imgs = Array.from(document.images).filter(img => img.src && img.width > 100 && img.height > 100);
        return imgs.length > 0 ? imgs[0].src : "";
      }
    }, (results) => {
      if (results && results[0]) {
        document.getElementById("imagem").value = results[0].result;
      }
    });
  }
});

// Preenche automaticamente o campo de link com a URL da aba atual
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs[0];
  if (tab) {
    document.getElementById("link").value = tab.url;
  }
});



// Também salva os dados no localStorage do site como 'dadosExtensao'
function salvarNoLocalStorageIndependente(titulo, imagem, link) {
  const chave = "dadosExtensao";
  const dados = JSON.parse(localStorage.getItem(chave)) || [];
  
  const novo = {
    id: Date.now().toString(36) + Math.random().toString(36).substring(2),
    nome: titulo || null,
    link: imagem || null,
    url: link || null
  };
  
  dados.push(novo);
  localStorage.setItem(chave, JSON.stringify(dados));
}

document.getElementById("meusLinks").addEventListener("click", () => {
  // Open a new tab with your Netlify app URL
  chrome.tabs.create({ url: "https://salva-links.netlify.app/" });
});