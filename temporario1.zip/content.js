chrome.storage.local.get("mfc_favoritos", (result) => {
  if (Array.isArray(result.mfc_favoritos)) {
    window.postMessage({
      type: "MFC_FAVORITOS_RECEBIDOS",
      favoritos: result.mfc_favoritos
    }, "*");
  }
});


// Listener para o comando do site
window.addEventListener("message", (event) => {
  // Verifica se a mensagem é do site e do tipo esperado
  if (event.source !== window || event.data.type !== "MFC_FAVORITOS_PROCESSADOS") return;
  
  const urlsProcessadas = event.data.favoritosIDs;
  
  // Remove os favoritos já transferidos do chrome.storage.local
  chrome.storage.local.get("mfc_favoritos", (result) => {
    const favoritosAtuais = Array.isArray(result.mfc_favoritos) ? result.mfc_favoritos : [];
    
    // Filtra mantendo apenas os favoritos que NÃO foram processados pelo site
    const novosFavoritos = favoritosAtuais.filter(
      fav => !urlsProcessadas.includes(fav.link)
    );
    
    // Atualiza o storage
    chrome.storage.local.set({ "mfc_favoritos": novosFavoritos });
  });
});